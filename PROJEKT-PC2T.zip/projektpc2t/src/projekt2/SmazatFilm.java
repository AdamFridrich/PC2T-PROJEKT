package projekt2;

import java.util.Scanner;

public class SmazatFilm extends PridatFilm implements FilmyInterface
{
    static void SmazFilm(final Scanner scanner) {
        System.out.println("Zadejte nazev filmu, ktery chcete Smazat:");
        scanner.nextLine();
        final String nazev = scanner.nextLine();
        final boolean found = false;
        for (final FilmyInterface film : SmazatFilm.AnimovaneFilmy) {
            if (film.getNazev().equals(nazev)) {
                SmazatFilm.AnimovaneFilmy.remove(film);
                System.out.println("Film byl uspesne smazan.");
                return;
            }
        }
        for (final FilmyInterface film : SmazatFilm.HraneFilmy) {
            if (film.getNazev().equals(nazev)) {
                SmazatFilm.HraneFilmy.remove(film);
                System.out.println("Film byl uspesne smazan.");
                return;
            }
        }
        if (!found) {
            System.out.println("Film se zadanym nazvem nebyl nalezen.");
        }
    }
    
    @Override
    public String getNazev() {
        return null;
    }
    
    @Override
    public String getReziser() {
        return null;
    }
    
    @Override
    public String getRokVydani() {
        return null;
    }
}
