package projekt2;

import java.util.Scanner;

public class PridatHodnoceni extends PridatFilm implements FilmyInterface
{
    public static void PridejHodnoceni(final Scanner scanner) {
        System.out.println("Zadejte nazev filmu, ktery chcete ohodnotit:");
        scanner.nextLine();
        final String nazev = scanner.nextLine();
        boolean found = false;
        for (final FilmyInterface film : PridatHodnoceni.HraneFilmy) {
            if (film.getNazev().equals(nazev)) {
                System.out.println("Zadejte hodnoceni divaku (* - *****):");
                final String hodnoceniDivaku = scanner.nextLine();
                ((HraneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                System.out.println("Hodnoceni bylo uspesne pridano.");
                found = true;
                break;
            }
        }
        for (final FilmyInterface film : PridatHodnoceni.AnimovaneFilmy) {
            if (film.getNazev().equals(nazev)) {
                System.out.println("Zadejte hodnoceni divaku (1 - 10):");
                final String hodnoceniDivaku = scanner.nextLine();
                ((AnimovaneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                System.out.println("Hodnoceni bylo uspesne pridano.");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Film se zadanym nazvem nebyl nalezen.");
        }
    }
}
