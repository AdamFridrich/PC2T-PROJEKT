package projekt2;

import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;

public class DBConnection
{
    private static volatile Connection dbConnection;
    
    private DBConnection() {
    }
    
    public static Connection getDBConnection() {
        if (DBConnection.dbConnection == null) {
            synchronized (DBConnection.class) {
                if (DBConnection.dbConnection == null) {
                    try {
                        Class.forName("org.sqlite.JDBC");
                        DBConnection.dbConnection = DriverManager.getConnection("jdbc:sqlite:sample.db");
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    catch (ClassNotFoundException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        return DBConnection.dbConnection;
    }
    
    public static void closeConnection() {
        try {
            if (DBConnection.dbConnection != null) {
                DBConnection.dbConnection.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}