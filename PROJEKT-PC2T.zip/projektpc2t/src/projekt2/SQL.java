package projekt2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQL implements FilmyInterface
{
    public static void UlozDoDatabaze() {
        try {
            Throwable t = null;
            try {
                final Connection conn = DriverManager.getConnection("jdbc:sqlite:sample.db");
                try {
                    final String droptable1 = "DROP TABLE AnimovaneFilmy;";
                    final String droptable2 = "DROP TABLE HraneFilmy;";
                    final String animovaneFilmyTableQuery = "CREATE TABLE IF NOT EXISTS AnimovaneFilmy (id INTEGER PRIMARY KEY AUTOINCREMENT, nazev TEXT, reziser TEXT, rokVydani INTEGER, seznamAnimatoru TEXT, hodnoceniDivaku INTEGER, doporucenyVek INTEGER)";
                    try {
                        final Statement stmt = conn.createStatement();
                        try {
                            stmt.executeUpdate(droptable1);
                            stmt.executeUpdate(droptable2);
                            stmt.executeUpdate(animovaneFilmyTableQuery);
                        }
                        finally {
                            if (stmt != null) {
                                stmt.close();
                            }
                        }
                    }
                    finally {}
                    final String hraneFilmyTableQuery = "CREATE TABLE IF NOT EXISTS HraneFilmy (id INTEGER PRIMARY KEY AUTOINCREMENT, nazev TEXT, reziser TEXT, rokVydani INTEGER, seznamHercu TEXT, hodnoceniDivaku INTEGER)";
                    try {
                        final Statement stmt2 = conn.createStatement();
                        try {
                            stmt2.executeUpdate(hraneFilmyTableQuery);
                        }
                        finally {
                            if (stmt2 != null) {
                                stmt2.close();
                            }
                        }
                    }
                    finally {}
                    final String animovaneFilmyInsertQuery = "INSERT INTO AnimovaneFilmy (nazev, reziser, rokVydani, seznamAnimatoru, hodnoceniDivaku, doporucenyVek) VALUES (?, ?, ?, ?, ?, ?)";
                    try {
                        final PreparedStatement stmt3 = conn.prepareStatement(animovaneFilmyInsertQuery);
                        try {
                            for (final AnimovaneFilmy film : SQL.AnimovaneFilmy) {
                                stmt3.setString(1, film.getNazev());
                                stmt3.setString(2, film.getReziser());
                                stmt3.setString(3, film.getRokVydani());
                                stmt3.setString(4, film.getSeznamAnimatoru());
                                stmt3.setString(5, film.getHodnoceniDivaku());
                                stmt3.setString(6, film.getDoporcenyVek());
                                stmt3.executeUpdate();
                            }
                        }
                        finally {
                            if (stmt3 != null) {
                                stmt3.close();
                            }
                        }
                    }
                    finally {}
                    final String hraneFilmyInsertQuery = "INSERT INTO HraneFilmy (nazev, reziser, rokVydani, seznamHercu, hodnoceniDivaku) VALUES (?, ?, ?, ?, ?)";
                    try {
                        final PreparedStatement stmt4 = conn.prepareStatement(hraneFilmyInsertQuery);
                        try {
                            for (final HraneFilmy film2 : SQL.HraneFilmy) {
                                stmt4.setString(1, film2.getNazev());
                                stmt4.setString(2, film2.getReziser());
                                stmt4.setString(3, film2.getRokVydani());
                                stmt4.setString(4, film2.getSeznamHercu());
                                stmt4.setString(5, film2.getHodnoceniDivaku());
                                stmt4.executeUpdate();
                            }
                        }
                        finally {
                            if (stmt4 != null) {
                                stmt4.close();
                            }
                        }
                    }
                    finally {}
                }
                finally {
                    if (conn != null) {
                        conn.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception = null;
                    t = exception;
                }
                else {
                    final Throwable exception = null;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            return;
        }
        finally {
            DBConnection.closeConnection();
        }
        DBConnection.closeConnection();
    }
    
    public static void NactiZDatabaze() {
        try {
            Throwable t = null;
            try {
                final Connection conn = DriverManager.getConnection("jdbc:sqlite:sample.db");
                try {
                    final String animovaneFilmySelectQuery = "SELECT * FROM AnimovaneFilmy";
                    try {
                        final PreparedStatement stmt = conn.prepareStatement(animovaneFilmySelectQuery);
                        try {
                            final ResultSet rs = stmt.executeQuery();
                            while (rs.next()) {
                                final String nazev = rs.getString("nazev");
                                final String reziser = rs.getString("reziser");
                                final String rokVydani = rs.getString("rokVydani");
                                final String seznamAnimatoru = rs.getString("seznamAnimatoru");
                                final String hodnoceniDivaku = rs.getString("hodnoceniDivaku");
                                final String doporucenyVek = rs.getString("doporucenyVek");
                                SQL.AnimovaneFilmy.add(new AnimovaneFilmy(nazev, reziser, rokVydani, seznamAnimatoru, hodnoceniDivaku, doporucenyVek));
                            }
                        }
                        finally {
                            if (stmt != null) {
                                stmt.close();
                            }
                        }
                    }
                    finally {}
                    final String hraneFilmySelectQuery = "SELECT * FROM HraneFilmy";
                    try {
                        final PreparedStatement stmt2 = conn.prepareStatement(hraneFilmySelectQuery);
                        try {
                            final ResultSet rs2 = stmt2.executeQuery();
                            while (rs2.next()) {
                                final String nazev2 = rs2.getString("nazev");
                                final String reziser2 = rs2.getString("reziser");
                                final String rokVydani2 = rs2.getString("rokVydani");
                                final String seznamHercu = rs2.getString("seznamHercu");
                                final String hodnoceniDivaku2 = rs2.getString("hodnoceniDivaku");
                                SQL.HraneFilmy.add(new HraneFilmy(nazev2, reziser2, rokVydani2, seznamHercu, hodnoceniDivaku2));
                            }
                        }
                        finally {
                            if (stmt2 != null) {
                                stmt2.close();
                            }
                        }
                    }
                    finally {}
                }
                finally {
                    if (conn != null) {
                        conn.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception = null;
                    t = exception;
                }
                else {
                    final Throwable exception = null;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            return;
        }
        finally {
            DBConnection.closeConnection();
        }
        DBConnection.closeConnection();
    }
    
    @Override
    public String getNazev() {
        return null;
    }
    
    @Override
    public String getReziser() {
        return null;
    }
    
    @Override
    public String getRokVydani() {
        return null;
    }
}
