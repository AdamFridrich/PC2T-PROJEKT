package projekt2;


public class AnimovaneFilmy implements FilmyInterface
{
    private String Nazev;
    private String Reziser;
    private String RokVydani;
    private String SeznamAnimatoru;
    private String HodnoceniDivaku;
    private String DoporcenyVek;
    
    public AnimovaneFilmy(final String Nazev, final String Reziser, final String RokVydani, final String SeznamAnimatoru, final String HodnoceniDivaku, final String DoporucenyVek) {
        this.Nazev = Nazev;
        this.Reziser = Reziser;
        this.RokVydani = RokVydani;
        this.setSeznamHercu(SeznamAnimatoru);
        this.setHodnoceniDivaku(HodnoceniDivaku);
        this.setDoporcenyVek(DoporucenyVek);
    }
    
    public String getNazev() {
        return this.Nazev;
    }
    
    public String getReziser() {
        return this.Reziser;
    }
    
    public String getRokVydani() {
        return this.RokVydani;
    }
    
    public String getSeznamAnimatoru() {
        return this.SeznamAnimatoru;
    }
    
    public void setSeznamHercu(final String seznamHercu) {
        this.SeznamAnimatoru = seznamHercu;
    }
    
    public String getHodnoceniDivaku() {
        return this.HodnoceniDivaku;
    }
    
    public void setHodnoceniDivaku(final String hodnoceniDivaku) {
        this.HodnoceniDivaku = hodnoceniDivaku;
    }
    
    public String getDoporcenyVek() {
        return this.DoporcenyVek;
    }
    
    public void setDoporcenyVek(final String doporucenyVek) {
        this.DoporcenyVek = doporucenyVek;
    }
    
    public void setSeznamAnimatoru(final String seznamAnimatoru2) {
    }
    
    public void setNazev(final String nazev) {
        this.Nazev = nazev;
    }
    
    public void setReziser(final String reziser) {
        this.Reziser = reziser;
    }
    
    public void setRokVydani(final String rokVydani) {
        this.RokVydani = rokVydani;
    }
}