package projekt2;

import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Scanner;

public class VypisFilmu implements FilmyInterface
{
    public VypisFilmu(final Scanner scanner) {
    }
    
    static void VypisVsechFilmu() {
        for (final HraneFilmy HranyFilm : VypisFilmu.HraneFilmy) {
            System.out.println("Vsechny hrane filmy: ");
            System.out.println(String.valueOf(HranyFilm.getNazev()) + " (" + HranyFilm.getRokVydani() + "), Reziser: " + HranyFilm.getReziser() + ", Hodnoceni: " + HranyFilm.getHodnoceniDivaku() + ", Obsazeni: " + HranyFilm.getSeznamHercu());
        }
        System.out.println(" ");
        for (final AnimovaneFilmy AnimovanyFilm : VypisFilmu.AnimovaneFilmy) {
            System.out.println("Vsechny animovane filmy: ");
            System.out.println(String.valueOf(AnimovanyFilm.getNazev()) + " (" + AnimovanyFilm.getRokVydani() + "), Reziser: " + AnimovanyFilm.getReziser() + ", Hodnoceni: " + AnimovanyFilm.getHodnoceniDivaku() + ", Animatori: " + AnimovanyFilm.getSeznamAnimatoru() + ", Doporuceny vek: " + AnimovanyFilm.getDoporcenyVek());
        }
        System.out.println(" ");
    }
    
    public static void VypisFilmuPodleNazvu(final Scanner scanner) {
        System.out.println("Zadejte nazev filmu, ktery chcete vyhledat:");
        scanner.nextLine();
        final String nazev = scanner.nextLine();
        boolean found = false;
        for (final HraneFilmy hranyFilm : VypisFilmu.HraneFilmy) {
            if (hranyFilm.getNazev().equals(nazev)) {
                found = true;
                System.out.println("Nazev: " + hranyFilm.getNazev());
                System.out.println("Rok vydani: " + hranyFilm.getRokVydani());
                System.out.println("Reziser: " + hranyFilm.getReziser());
                System.out.println("Hodnoceni divaku: " + hranyFilm.getHodnoceniDivaku());
                System.out.println("Obsazeni: " + hranyFilm.getSeznamHercu());
            }
        }
        for (final AnimovaneFilmy animovanyFilm : VypisFilmu.AnimovaneFilmy) {
            if (animovanyFilm.getNazev().equals(nazev)) {
                found = true;
                System.out.println("Nazev: " + animovanyFilm.getNazev());
                System.out.println("Rok vydani: " + animovanyFilm.getRokVydani());
                System.out.println("Reziser: " + animovanyFilm.getReziser());
                System.out.println("Hodnoceni divaku: " + animovanyFilm.getHodnoceniDivaku());
                System.out.println("Animatori: " + animovanyFilm.getSeznamAnimatoru());
                System.out.println("Doporuceny vek: " + animovanyFilm.getDoporcenyVek());
            }
            if (!found) {
                System.out.println("Film s n\u00e1zvem " + nazev + " nebyl nalezen.");
            }
        }
    }
    
    public static void VypisPodleAnimatoraNeboHerce(final Scanner scanner) {
        System.out.println("Chcete vypsat herce nebo animatory, kte\u0159\u00ed se pod\u00edleli na v\u00edce ne\u017e jednom filmu?");
        System.out.println("1 - Herci");
        System.out.println("2 - Animatori");
        final int volba = scanner.nextInt();
        final Map<String, List<String>> mapa = new HashMap<String, List<String>>();
        switch (volba) {
            case 1: {
                for (final HraneFilmy hranyfilm : VypisFilmu.HraneFilmy) {
                    final String[] herci = hranyfilm.getSeznamHercu().split(",");
                    String[] array;
                    for (int length = (array = herci).length, i = 0; i < length; ++i) {
                        final String herec = array[i];
                        if (!mapa.containsKey(herec)) {
                            final List<String> filmy = new ArrayList<String>();
                            filmy.add(hranyfilm.getNazev());
                            mapa.put(herec, filmy);
                        }
                        else {
                            mapa.get(herec).add(hranyfilm.getNazev());
                        }
                    }
                }
                break;
            }
            case 2: {
                for (final AnimovaneFilmy animovanyfilm : VypisFilmu.AnimovaneFilmy) {
                    final String[] animatori = animovanyfilm.getSeznamAnimatoru().split(",");
                    String[] array2;
                    for (int length2 = (array2 = animatori).length, j = 0; j < length2; ++j) {
                        final String animator = array2[j];
                        if (!mapa.containsKey(animator)) {
                            final List<String> filmy = new ArrayList<String>();
                            filmy.add(animovanyfilm.getNazev());
                            mapa.put(animator, filmy);
                        }
                        else {
                            mapa.get(animator).add(animovanyfilm.getNazev());
                        }
                    }
                }
                break;
            }
            default: {
                System.out.println("Neplatn\u00e1 volba.");
                return;
            }
        }
        for (final Map.Entry<String, List<String>> entry : mapa.entrySet()) {
            final String osoba = entry.getKey();
            final List<String> filmy2 = entry.getValue();
            if (filmy2.size() > 1) {
                System.out.println(String.valueOf(osoba) + ": " + filmy2);
            }
        }
    }
    
    public static void VypisFilmuPodleOsoby(final Scanner scanner) {
        System.out.println("Zadejte jm\u00e9no herce nebo anim\u00e1tora:");
        scanner.nextLine();
        final String osoba = scanner.nextLine();
        boolean found = false;
        for (final HraneFilmy hranyFilm : VypisFilmu.HraneFilmy) {
            if (hranyFilm.getSeznamHercu().contains(osoba)) {
                found = true;
                System.out.print(String.valueOf(hranyFilm.getNazev()) + ", ");
            }
        }
        for (final AnimovaneFilmy animovanyFilm : VypisFilmu.AnimovaneFilmy) {
            if (animovanyFilm.getSeznamAnimatoru().contains(osoba)) {
                found = true;
                System.out.print(String.valueOf(animovanyFilm.getNazev()) + ", ");
            }
        }
        System.out.println(" ");
        if (!found) {
            System.out.println("Osoba " + osoba + " nehr\u00e1la v \u017e\u00e1dn\u00e9m z film\u016f.");
        }
    }
    
    @Override
    public String getNazev() {
        return null;
    }
    
    @Override
    public String getReziser() {
        return null;
    }
    
    @Override
    public String getRokVydani() {
        return null;
    }
    
    public static void UpravitFilm(final String name) {
    }
}
