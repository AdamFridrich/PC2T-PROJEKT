package projekt2;

public class HraneFilmy implements FilmyInterface
{
    private String Nazev;
    private String Reziser;
    private String RokVydani;
    private String SeznamHercu;
    private String HodnoceniDivaku;
    
    public HraneFilmy(final String Nazev, final String Reziser, final String RokVydani, final String SeznamHercu, final String HodnoceniDivaku) {
        this.Nazev = Nazev;
        this.Reziser = Reziser;
        this.RokVydani = RokVydani;
        this.setSeznamHercu(SeznamHercu);
        this.setHodnoceniDivaku(HodnoceniDivaku);
    }
    
    @Override
    public String getNazev() {
        return this.Nazev;
    }
    
    @Override
    public String getReziser() {
        return this.Reziser;
    }
    
    @Override
    public String getRokVydani() {
        return this.RokVydani;
    }
    
    public String getSeznamHercu() {
        return this.SeznamHercu;
    }
    
    public void setSeznamHercu(final String seznamHercu) {
        this.SeznamHercu = seznamHercu;
    }
    
    public String getHodnoceniDivaku() {
        return this.HodnoceniDivaku;
    }
    
    public void setHodnoceniDivaku(final String hodnoceniDivaku) {
        this.HodnoceniDivaku = hodnoceniDivaku;
    }
    
    public void setNazev(final String nazev) {
        this.Nazev = nazev;
    }
    
    public void setReziser(final String reziser) {
        this.Reziser = reziser;
    }
    
    public void setRokVydani(final String rokVydani) {
        this.RokVydani = rokVydani;
    }
}