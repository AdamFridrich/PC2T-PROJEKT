package projekt2;

import java.util.Collection;

public class VsechnyFilmy implements FilmyInterface
{
    private String nazev;
    private String reziser;
    private String rokVydani;
    
    public VsechnyFilmy(final String nazev, final String reziser, final String rokVydani) {
        this.nazev = nazev;
        this.reziser = reziser;
        this.rokVydani = rokVydani;
    }
    
    @Override
    public String getNazev() {
        return this.nazev;
    }
    
    @Override
    public String getReziser() {
        return this.reziser;
    }
    
    @Override
    public String getRokVydani() {
        return this.rokVydani;
    }
    
    public Collection<? extends VsechnyFilmy> getSeznamAnimatoru() {
        return null;
    }
    
    public Collection<? extends VsechnyFilmy> getSeznamHercu() {
        return null;
    }
}
