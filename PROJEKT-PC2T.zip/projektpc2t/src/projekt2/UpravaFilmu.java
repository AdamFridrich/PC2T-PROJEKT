package projekt2;

import java.util.Scanner;

public class UpravaFilmu extends PridatFilm implements FilmyInterface
{
    public static void UpravitFilm(final Scanner scanner) {
        System.out.println("Zadejte nazev filmu, ktery chcete ohodnotit:");
        scanner.nextLine();
        final String nazev2 = scanner.nextLine();
        boolean found = false;
        for (final FilmyInterface film : UpravaFilmu.AnimovaneFilmy) {
            if (film.getNazev().equals(nazev2)) {
                System.out.println("Zadejte novy nazev filmu: ");
                final String nazev3 = scanner.nextLine();
                System.out.println("Zadejte noveho rezisera: ");
                final String reziser = scanner.nextLine();
                System.out.println("Zadejte novy rok vydani: ");
                final String rokVydani = scanner.nextLine();
                if (film instanceof HraneFilmy) {
                    System.out.println("Zadejte nove hodnoceni divaku (* - *****): ");
                    final String hodnoceniDivaku = scanner.nextLine();
                    System.out.println("Zadejte nove obsazeni: ");
                    final String seznamHercu = scanner.nextLine();
                    ((HraneFilmy)film).setNazev(nazev3);
                    ((HraneFilmy)film).setReziser(reziser);
                    ((HraneFilmy)film).setRokVydani(rokVydani);
                    ((HraneFilmy)film).setSeznamHercu(seznamHercu);
                    ((HraneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                }
                else {
                    System.out.println("Zadejte nove hodnoceni divaku (1 - 10): ");
                    final String hodnoceniDivaku = scanner.nextLine();
                    System.out.println("Zadejte nove animatory: ");
                    final String seznamAnimatoru = scanner.nextLine();
                    System.out.println("Zadejte novy doporuceny vek: ");
                    final String doporucenyVek = scanner.nextLine();
                    ((AnimovaneFilmy)film).setNazev(nazev3);
                    ((AnimovaneFilmy)film).setReziser(reziser);
                    ((AnimovaneFilmy)film).setRokVydani(rokVydani);
                    ((AnimovaneFilmy)film).setSeznamAnimatoru(seznamAnimatoru);
                    ((AnimovaneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                    ((AnimovaneFilmy)film).setDoporcenyVek(doporucenyVek);
                }
                found = true;
                System.out.println("Film byl uspesne upraven.");
                break;
            }
        }
        for (final FilmyInterface film : UpravaFilmu.HraneFilmy) {
            if (film.getNazev().equals(nazev2)) {
                System.out.println("Zadejte novy nazev filmu: ");
                final String nazev3 = scanner.nextLine();
                System.out.println("Zadejte noveho rezisera: ");
                final String reziser = scanner.nextLine();
                System.out.println("Zadejte novy rok vydani: ");
                final String rokVydani = scanner.nextLine();
                if (film instanceof HraneFilmy) {
                    System.out.println("Zadejte nove hodnoceni divaku (* - *****): ");
                    final String hodnoceniDivaku = scanner.nextLine();
                    System.out.println("Zadejte nove obsazeni: ");
                    final String seznamHercu = scanner.nextLine();
                    ((HraneFilmy)film).setNazev(nazev3);
                    ((HraneFilmy)film).setReziser(reziser);
                    ((HraneFilmy)film).setRokVydani(rokVydani);
                    ((HraneFilmy)film).setSeznamHercu(seznamHercu);
                    ((HraneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                }
                else {
                    System.out.println("Zadejte nove hodnoceni divaku (1 - 10): ");
                    final String hodnoceniDivaku = scanner.nextLine();
                    System.out.println("Zadejte nove animatory: ");
                    final String seznamAnimatoru = scanner.nextLine();
                    System.out.println("Zadejte novy doporuceny vek: ");
                    final String doporucenyVek = scanner.nextLine();
                    ((AnimovaneFilmy)film).setNazev(nazev3);
                    ((AnimovaneFilmy)film).setReziser(reziser);
                    ((AnimovaneFilmy)film).setRokVydani(rokVydani);
                    ((AnimovaneFilmy)film).setSeznamAnimatoru(seznamAnimatoru);
                    ((AnimovaneFilmy)film).setHodnoceniDivaku(hodnoceniDivaku);
                    ((AnimovaneFilmy)film).setDoporcenyVek(doporucenyVek);
                }
                found = true;
                System.out.println("Film byl uspesne upraven.");
                break;
            }
        }
        if (!found) {
            System.out.println("Film se zadanym nazvem nebyl nalezen.");
        }
    }
}
