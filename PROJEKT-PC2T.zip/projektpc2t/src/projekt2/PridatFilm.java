package projekt2;

import java.util.Scanner;

public class PridatFilm implements FilmyInterface
{
    public static void PridejFilm(final Scanner scanner) {
        System.out.println("Jaky film chcete pridat?");
        System.out.println("1 - Hrany");
        System.out.println("2 - Animovany");
        int TypFilmu = scanner.nextInt();
        switch (TypFilmu) {
            case 1: {
                System.out.println("Zadejte nazev:");
                String nazev = scanner.next();
                System.out.println("Zadejte jmeno rezisera:");
                String reziser = scanner.next();
                System.out.println("Zadejte rok vydani:");
                String rokVydani = scanner.next();
                System.out.println("Zadejte seznam hercu:");
                String seznamHercu = scanner.next();
                System.out.println("Zadejte hodnoceni divaku (* - *****):");
                String hodnoceniDivaku = scanner.next();
                HraneFilmy Hranyfilm = new HraneFilmy(nazev, reziser, rokVydani, seznamHercu, hodnoceniDivaku);
                PridatFilm.HraneFilmy.add(Hranyfilm);
                System.out.println("Hrany film byl uspesne pridan.");
                break;
            }
            case 2: {
                System.out.println("Zadejte nazev:");
                String nazev = scanner.next();
                System.out.println("Zadejte jmeno rezisera:");
                String reziser = scanner.next();
                System.out.println("Zadejte rok vydani:");
                String rokVydani = scanner.next();
                System.out.println("Zadejte seznam animatoru:");
                String seznamAnimatoru = scanner.next();
                System.out.println("Zadejte hodnoceni divaku (1 - 10):");
                String hodnoceniDivaku = scanner.next();
                System.out.println("Zadejte doporuceny vek:");
                String DoporucenyVek = scanner.next();
                AnimovaneFilmy Animovanyfilm = new AnimovaneFilmy(nazev, reziser, rokVydani, seznamAnimatoru, hodnoceniDivaku, DoporucenyVek);
                PridatFilm.AnimovaneFilmy.add(Animovanyfilm);
                System.out.println("Animovany film byl uspesne pridan.");
                break;
            }
        }
    }
    
    @Override
    public String getNazev() {
        return getNazev();
    }
    
    @Override
    public String getReziser() {
        return null;
    }
    
    @Override
    public String getRokVydani() {
        return null;
    }
}