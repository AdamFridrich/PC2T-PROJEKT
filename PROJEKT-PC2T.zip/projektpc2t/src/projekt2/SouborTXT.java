package projekt2;

import java.util.InputMismatchException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.io.File;
import java.util.Scanner;

public class SouborTXT implements FilmyInterface
{
    public static void UlozDoSouboru(final Scanner scanner) {
        System.out.println("Zadejte nazev filmu, ktery chcete ulozit do souboru:");
        scanner.nextLine();
        final String nazev = scanner.nextLine();
        boolean found = false;
        String info = "";
        for (final HraneFilmy hranyFilm : SouborTXT.HraneFilmy) {
            if (hranyFilm.getNazev().equals(nazev)) {
                found = true;
                info = String.valueOf(info) + "Hrane\n";
                info = String.valueOf(info) + "Nazev: " + hranyFilm.getNazev() + "\n";
                info = String.valueOf(info) + "Rok vydani: " + hranyFilm.getRokVydani() + "\n";
                info = String.valueOf(info) + "Reziser: " + hranyFilm.getReziser() + "\n";
                info = String.valueOf(info) + "Hodnoceni divaku: " + hranyFilm.getHodnoceniDivaku() + "/*****" + "\n";
                info = String.valueOf(info) + "Obsazeni: " + hranyFilm.getSeznamHercu() + "\n";
            }
        }
        for (final AnimovaneFilmy animovanyFilm : SouborTXT.AnimovaneFilmy) {
            if (animovanyFilm.getNazev().equals(nazev)) {
                found = true;
                info = String.valueOf(info) + "Animovane\n";
                info = String.valueOf(info) + "Nazev: " + animovanyFilm.getNazev() + "\n";
                info = String.valueOf(info) + "Rok vydani: " + animovanyFilm.getRokVydani() + "\n";
                info = String.valueOf(info) + "Reziser: " + animovanyFilm.getReziser() + "\n";
                info = String.valueOf(info) + "Hodnoceni divaku: " + animovanyFilm.getHodnoceniDivaku() + "/10" + "\n";
                info = String.valueOf(info) + "Animatori: " + animovanyFilm.getSeznamAnimatoru() + "\n";
                info = String.valueOf(info) + "Doporuceny vek: " + animovanyFilm.getDoporcenyVek() + "\n";
            }
        }
        if (!found) {
            System.out.println("Film s n\u00e1zvem " + nazev + " nebyl nalezen.");
            return;
        }
        try {
            final File file = new File(String.valueOf(nazev) + ".txt");
            final FileWriter writer = new FileWriter(file);
            writer.write(info);
            writer.close();
            System.out.println("Informace o filmu byly ulozeny do souboru " + file.getName());
        }
        catch (IOException e) {
            System.out.println("Nepodarilo se ulozit informace o filmu do souboru.");
        }
    }
    
    public static void NactiZeSouboru(final Scanner scanner) {
        scanner.nextLine();
        System.out.println("Zadejte nazev souboru, ze ktereho chcete nacist informace o filmu:");
        final String nazevSouboru = scanner.nextLine();
        final File file = new File(String.valueOf(nazevSouboru) + ".txt");
        if (!file.exists()) {
            System.out.println("Soubor s informacemi o filmu nebyl nalezen.");
            return;
        }
        try {
            Throwable t = null;
            try {
                final Scanner fileScanner = new Scanner(file);
                try {
                    final String typFilmu = fileScanner.nextLine();
                    final String nazev = fileScanner.nextLine();
                    final String rokVydani = fileScanner.nextLine();
                    fileScanner.nextLine();
                    final String reziser = fileScanner.nextLine();
                    final String hodnoceniDivaku = fileScanner.nextLine();
                    fileScanner.nextLine();
                    if (typFilmu.equalsIgnoreCase("Animovany")) {
                        final String seznamAnimatoru = fileScanner.nextLine();
                        final String doporucenyVek = fileScanner.nextLine();
                        fileScanner.nextLine();
                        final AnimovaneFilmy film = new AnimovaneFilmy(nazev, rokVydani, reziser, hodnoceniDivaku, seznamAnimatoru, doporucenyVek);
                        final int index = SouborTXT.AnimovaneFilmy.indexOf(film);
                        if (index >= 0) {
                            SouborTXT.AnimovaneFilmy.set(index, film);
                            System.out.println("Film " + nazev + " byl nacten.");
                        }
                        else {
                            System.out.println("Film s nazvem " + nazev + " nebyl nalezen.");
                        }
                    }
                    else if (typFilmu.equalsIgnoreCase("Hrany")) {
                        final String obsazeni = fileScanner.nextLine();
                        final HraneFilmy film2 = new HraneFilmy(nazev, rokVydani, reziser, hodnoceniDivaku, obsazeni);
                        final int index2 = SouborTXT.HraneFilmy.indexOf(film2);
                        if (index2 >= 0) {
                            SouborTXT.HraneFilmy.set(index2, film2);
                            System.out.println("Film " + nazev + " byl nacten.");
                        }
                        else {
                            System.out.println("Film s nazvem " + nazev + " nebyl nalezen.");
                        }
                    }
                    else {
                        System.out.println("Neplatny typ filmu.");
                    }
                }
                finally {
                    if (fileScanner != null) {
                        fileScanner.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception = null;
                    t = exception;
                }
                else {
                    final Throwable exception = null;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Soubor s informacemi o filmu nebyl nalezen.");
        }
        catch (InputMismatchException e2) {
            System.out.println("Chyba pri nacitani souboru s informacemi o filmu.");
        }
    }
    
    @Override
    public String getNazev() {
        return null;
    }
    
    @Override
    public String getReziser() {
        return null;
    }
    
    @Override
    public String getRokVydani() {
        return null;
    }
}
