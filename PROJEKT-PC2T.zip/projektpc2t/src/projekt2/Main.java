package projekt2;

import java.util.Scanner;

public class Main
{
    public static void main(final String[] args) {
        SQL.NactiZDatabaze();
        final Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("Vyberte akci:");
            System.out.println("1 - Pridat film");
            System.out.println("2 - Vypsat vsechny filmy");
            System.out.println("3 - Uprava filmu");
            System.out.println("4 - Smazat film");
            System.out.println("5 - Pridat hodnoceni filmu");
            System.out.println("6 - Vypis filmu podle nazvu");
            System.out.println("7 - Herci/Animatori, kteri se podileli na vice filmech");
            System.out.println("8 - Vypis filmu podle animatora nebo herce");
            System.out.println("9 - Ulozit informace o filmu do souboru");
            System.out.println("10 - Nacist informace o filmu ze souboru");
            System.out.println("0 - Konec");
            int volba = scanner.nextInt();
            switch (volba) {
                case 0: {
                    SQL.UlozDoDatabaze();
                    running = false;
                    break;
                }
                case 1: {
                    PridatFilm.PridejFilm(scanner);
                    break;
                }
                case 2: {
                    VypisFilmu.VypisVsechFilmu();
                    break;
                }
                case 3: {
                    UpravaFilmu.UpravitFilm(scanner);
                    break;
                }
                case 4: {
                    SmazatFilm.SmazFilm(scanner);
                    break;
                }
                case 5: {
                    PridatHodnoceni.PridejHodnoceni(scanner);
                    break;
                }
                case 6: {
                    VypisFilmu.VypisFilmuPodleNazvu(scanner);
                    break;
                }
                case 7: {
                    VypisFilmu.VypisPodleAnimatoraNeboHerce(scanner);
                    break;
                }
                case 8: {
                    VypisFilmu.VypisFilmuPodleOsoby(scanner);
                    break;
                }
                case 9: {
                    SouborTXT.UlozDoSouboru(scanner);
                    break;
                }
                case 10: {
                    SouborTXT.NactiZeSouboru(scanner);
                    break;
                }
                default: {
                    System.out.println("Spatna volba, zkuste to znovu.");
                    break;
                }
            }
        }
    }
}
