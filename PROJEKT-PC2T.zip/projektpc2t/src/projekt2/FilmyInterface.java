package projekt2;

import java.util.ArrayList;
import java.util.List;

public interface FilmyInterface
{
    public static final List<HraneFilmy> HraneFilmy = new ArrayList<HraneFilmy>();
    public static final List<AnimovaneFilmy> AnimovaneFilmy = new ArrayList<AnimovaneFilmy>();
    
    String getNazev();
    
    String getReziser();
    
    String getRokVydani();
}
