/**
 * 
 */
/**
 * @author Adam
 *
 */
module projekt2 {
	requires java.sql;
}